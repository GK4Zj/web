<?php

namespace MyProject\Classes;

interface SuperUserInterface {
    public function getInfo();
}

?>