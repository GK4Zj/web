
<?php 

// Server name must be localhost 
$servername = "localhost"; 

// In my case, user name will be root 
$username = "ironfox500"; 

// Password is empty 
$password = "NWZ616UU%u6RX9JL"; 

// Creating a connection 
$conn = new mysqli($servername, 
			$username, $password); 


?>