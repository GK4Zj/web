<?php

namespace Project\Controllers;

use Core\Controller;

class TestController extends Controller
{
    public function act1()
    {
        echo "раз";
    }

    public function act2()
    {
        echo "два";
    }

    public function act3()
    {
        echo "три";
    }
}