<?php
namespace MVC\Views;

class UserHtmlView extends HtmlView {}
