<?php

namespace RefactoringGuru\Interpreter\RealWorld;

/**
 * Паттерн Интерпретатор
 *
 * Определяет грамматику простого языка, представляет предложения на этом языке и интерпретирует их.
 */
class Context
{
    private $poolVariable;

    public function lookUp(string $name): bool
    {
        if (!key_exists($name, $this->poolVariable)) {
            die("Несуществующая переменная: $name");
        }

        return $this->poolVariable[$name];
    }

    public function assign(VariableExp $variable, $val)
    {
        $this->poolVariable[$variable->getName()] = $val;
    }
}

abstract class AbstractExp
{
    abstract public function interpret(Context $context): bool;
}

class VariableExp extends AbstractExp
{
    private $name;

    public function __construct(string $name)
    {
        $this->name = $name;
    }

    public function interpret(Context $context): bool
    {
        return $context->lookUp($this->name);
    }

    public function getName(): string
    {
        return $this->name;
    }
}

class AndExp extends AbstractExp
{
    private $first;
    private $second;

    public function __construct(AbstractExp $first, AbstractExp $second)
    {
        $this->first  = $first;
        $this->second = $second;
    }

    public function interpret(Context $context): bool
    {
        return (bool)$this->first->interpret($context) && $this->second->interpret($context);
    }
}

class OrExp extends AbstractExp
{
    private $first;
    private $second;

    public function __construct(AbstractExp $first, AbstractExp $second)
    {
        $this->first  = $first;
        $this->second = $second;
    }

    public function interpret(Context $context): bool
    {
        return $this->first->interpret($context) || $this->second->interpret($context);
    }
}

/**
 * Клиентский код.
 */

$context = new Context();

$a = new VariableExp('A');
$b = new VariableExp('B');
$c = new VariableExp('C');

// Пример 1:
// A ∧ (B ∨ C)
$exp = new AndExp(
    $a,
    new OrExp($b, $c)
);

$context->assign($a, true);
$context->assign($b, true);
$context->assign($c, false);

$result = $exp->interpret($context) ? 'истина' : 'ложь';

echo 'Логическое выражение A ∧ (B ∨ C) = ' . $result . ', где A=истина, B=истина, C=ложь' . PHP_EOL;


// Пример 2:
// B ∨ (A ∧ (B ∨ C))
$exp = new OrExp(
    $b,
    new AndExp(
        $a,
        new OrExp($b, $c)
    )
);

$context->assign($a, false);
$context->assign($b, false);
$context->assign($c, true);

$result2 = $exp->interpret($context) ? 'истина' : 'ложь';

echo 'Логическое выражение B ∨ (A ∧ (B ∨ C)) = ' . $result2 . ', где A=ложь, B=ложь, C=истина';